LocalDevX v1.0.0 - portable version
===================================

No installation needed: double-click LocalDevX.exe to run it from this folder.
You can move the folder anywhere, e.g. a USB drive or C:\Tools\LocalDevX.

- Windows asks for Administrator rights: LocalDevX edits the hosts file and controls Apache.
- Settings and your site list are stored in %APPDATA%\LocalDevX and shared with the installed
  version, so you can switch between portable and installed at any time.
- Only one copy runs at a time. If "Start with Windows" is on, it starts whichever copy
  you used most recently.
- To remove the portable version, quit it (tray icon -> Quit) and delete this folder.

Created by Andy Christian S. Loyola <acl20032003@gmail.com>
